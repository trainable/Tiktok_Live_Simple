export default class MediaList {
  constructor () {
    this.video = []
    this.audio = []
  }
}
