import I18N from './i18n'
export default I18N
