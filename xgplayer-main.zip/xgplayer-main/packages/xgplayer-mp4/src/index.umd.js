import Mp4Plugin from './mp4Plugin'
export default Mp4Plugin
