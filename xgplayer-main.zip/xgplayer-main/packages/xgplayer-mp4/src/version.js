/**
 * @type {string}
 * */
export default __VERSION__
