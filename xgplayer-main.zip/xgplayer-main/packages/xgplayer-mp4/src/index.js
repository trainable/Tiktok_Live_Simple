import Mp4Plugin from './mp4Plugin'
export {
  Mp4Plugin as default
}
