import { MP4Loader } from './loader'

export default MP4Loader
