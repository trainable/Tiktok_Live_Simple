---
name: 问题反馈 Bug report
about: Describe this issue template's purpose here.
title: ''
labels: ''
assignees: ''

---

**您使用的西瓜播放器版本是多少？ What version of xgplayer are you using?**


**您使用的操作系统和浏览器分别是？ What OS and browser are you using?**


**如何复现问题？ How to reproduce the problem?**

<!--
如果您用 [codepen](https://codepen.io/) 或者 [codesandbox](https://codesandbox.io/) 等工具还原一下问题并提供demo地址，这样会加快我们识别及解决问题的进度 If you use tools such as [codepen](https://codepen.io/) or [codesandbox](https://codesandbox.io/) to restore the problem and provide a demo address, this will speed up our process of identifying and solving problems?
-->



**您期望的播放器正常行为是？ What did you expect to happen?**


**实际播放器的表现是？ What actually happened?**


**可填写您所在的公司和相关产品业务，方便我们提供更好的技术支持 You can write your company and product which uses xgplayer,  for helping us provide better technical support.**
