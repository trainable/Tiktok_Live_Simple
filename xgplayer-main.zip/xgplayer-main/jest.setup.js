global.__VERSION__ = 'test'
